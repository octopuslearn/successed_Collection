#ifndef _MIRMOUSE_FLASH_H_
#define _MIRMOUSE_FLASH_H_
#include "MicroMouse_Define.h"
#include "stm32f10x.h"
void MirMouse_WriteMapInf(void);
void MirMouse_ReadMapInf(void);
#endif

