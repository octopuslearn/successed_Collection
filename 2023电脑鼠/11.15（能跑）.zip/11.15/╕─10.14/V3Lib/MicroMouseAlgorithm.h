#ifndef _MICROMOUSE_ALGORITHM_H_
#define _MICROMOUSE_ALGORITHM_H_
#include "MicroMouse_Define.h"
//typedef struct mazecoor
//{
//    char cX;
//    char cY;
//}MAZECOOR;

#define MAZETYPE                16

MAZECOOR  GmcStackn[MAZETYPE*MAZETYPE];
MAZECOOR  GmcStackm[MAZETYPE*MAZETYPE];

#endif /* _MICROMOUSE_ALGORITHM_H_ */

