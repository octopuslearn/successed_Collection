#ifndef _JDY31_H_
#define _JDY31_H_

#include "car.h"

extern unsigned char JDY31_mode;

void JDY31_judgement();
void UartInit(void);

#endif